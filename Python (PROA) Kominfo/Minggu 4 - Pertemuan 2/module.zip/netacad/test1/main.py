import module

print(module.counter)
