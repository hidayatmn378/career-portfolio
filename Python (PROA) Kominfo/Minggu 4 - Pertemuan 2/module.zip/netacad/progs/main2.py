#from sys import path
#path.append('..//packages')

#import extra.iota
#print(extra.iota.funI())


#from sys import path
#path.append('..//packages')

#from extra.iota import funI
#print(funI())

#from sys import path

#path.append('..//packages')

#import extra.good.best.sigma
#from extra.good.best.tau import funT

#print(extra.good.best.sigma.funS())
#print(funT())

#from sys import path

#path.append('..//packages')

#import extra.good.best.sigma as sig
#import extra.good.alpha as alp

#print(sig.funS())
#print(alp.funA())

#note: in the zip file fun* become Fun*
from sys import path

path.append('..//packages//extrapack.zip')

import extra.good.best.sigma as sig
import extra.good.alpha as alp
from extra.iota import FunI
from extra.good.beta import FunB

print(sig.FunS())
print(alp.FunA())
print(FunI())
print(FunB())



