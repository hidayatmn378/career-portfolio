import latihan_package.alpha as a
import latihan_package.beta as b
import mnh.call as panggilan
import latihan_package.folder_nested.aritmatika as ar

a.alphaSatu()
b.betaDua()
panggilan.call_me()	

z = ar.tambah(4, 5)
print(z)

