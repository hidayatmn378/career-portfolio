def alphaSatu():
	print("alphaSatu")
def alphaDua():
	print("alphaDua")
