def call_me():
	print("mnh")
