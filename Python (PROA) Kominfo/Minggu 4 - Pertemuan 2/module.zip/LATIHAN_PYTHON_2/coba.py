import os
import latihan_package.alpha as a

a.alphaDua()
