import aritmatika as ar

a = ar.tambah(4, 5)
b = ar.kurang(4, 5)
c = ar.kali(4, 5)
d = ar.bagi(4, 5)
print(a)
print(b)
print(c)
print(d)
